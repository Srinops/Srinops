package com.qaorg.framework.utilities;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.testng.log4testng.Logger;

import com.qaorg.framework.base.DriverManager;

import io.cucumber.core.api.Scenario;

public class UIWrappers {
	
	/**
	 * This method is used to click web element in AUT
	 * @param element
	 */
	public static void clickElement(WebElement element) {
		Logger.getLogger(UIWrappers.class).info(UIWrappers.class.getEnclosingMethod().getName());
		DriverWait.isElementDisplayed(element);
		element.click();
	}
	
	/**
	 * This method is used to enter text in text field in AUT
	 * @param element
	 * @param inputText
	 */
	public static void inputText(WebElement element,String inputText) {
		Logger.getLogger(UIWrappers.class).info(UIWrappers.class.getEnclosingMethod().getName());
		DriverWait.isElementDisplayed(element);
		element.sendKeys(inputText);
	}
	
	/**
	 * This method is used to remove text in text field in AUT
	 * @param element
	 */
	public static void clear(WebElement element) {
		Logger.getLogger(UIWrappers.class).info(UIWrappers.class.getEnclosingMethod().getName());
		DriverWait.isElementDisplayed(element);
		element.clear();
	}
	
	public static void takeScreenShot(Scenario scenario, String... screenShotName) {
		Logger.getLogger(UIWrappers.class).info(UIWrappers.class.getEnclosingMethod().getName());
		final byte[] screenshot = ((TakesScreenshot) DriverManager.getDriver()).getScreenshotAs(OutputType.BYTES);
		if (screenShotName.length > 0) {
			scenario.embed(screenshot, "image/png", screenShotName[0]);
		} else {
			scenario.embed(screenshot, "image/png", scenario.getName());
		}
	}
}
