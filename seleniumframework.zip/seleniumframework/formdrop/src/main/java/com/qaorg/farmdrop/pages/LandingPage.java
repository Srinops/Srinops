package com.qaorg.farmdrop.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.qaorg.framework.utilities.DriverWait;
import com.qaorg.framework.utilities.UIWrappers;

public class LandingPage extends BasePage{
	
	public LandingPage() {
		super();
	}
	
	@FindBy(xpath="//a[contains(@class,'loginButton')]") private WebElement loginBtn;
	
	public LoginPage clickLoginButton() {
		Assert.assertTrue(isPageDisplayed(),"Application is not launched");
		UIWrappers.clickElement(loginBtn);
		Assert.assertTrue(new LoginPage().isPageDisplayed(), "Login page is not displayed");
		return new LoginPage();
	}

	@Override
	public boolean isPageDisplayed() {
		return DriverWait.isElementDisplayed(loginBtn);
	}
}
