package com.qaorg.framework.utilities;

import io.cucumber.core.api.Scenario;

/**
 * Reporter class for logging messages in cucumber reports
 */

public class Reporter {
	private Scenario logger;

	public Reporter(Scenario scenario) {
		logger = scenario;
	}
	
	/**
	 * Log message in cucumber reports
	 * @param message - message to log in cucumber report
	 */
	public void logger(String message) {
		logger.write(message);
	}
}
