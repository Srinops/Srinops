package com.qaorg.farmdrop.runner;

import com.qaorg.framework.base.CucumberFeatureManager;

import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
		dryRun = false,
		monochrome=true,
		strict = true,
		features = "src/test/resources/features",
		glue = {"com.qaorg.farmdrop.stepdefinitions" },
		tags = "@signuphappyflow",
		plugin = {"html:target/cucumber-reports/cucumber-pretty",
				"json:target/cucumber-reports/cucumber-html-report.json",
				"usage:target/cucumber-reports/cucumber-usage.json",
				"rerun:target/cucumber-reports/failedscenarios.txt" })

public class RunCukesTest extends CucumberFeatureManager {
}
