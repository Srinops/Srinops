package com.qaorg.farmdrop.stepdefinitions;

import com.qaorg.farmdrop.pages.LandingPage;
import com.qaorg.farmdrop.pages.LoginPage;

import io.cucumber.java.en.Given;

public class LoginStepDefinitions{
	
	private LandingPage landingPage;
	private LoginPage loginPage;
	
	public LoginStepDefinitions(LandingPage landingPage,LoginPage loginPage) {
		this.landingPage=landingPage;
		this.loginPage=loginPage;
	}
	
	@Given("User navigates to SignUp form page")
	public void user_navigates_to_SignUp_form_page() {
		landingPage.clickLoginButton();
		loginPage.clickSignUpLink();
	}
}
