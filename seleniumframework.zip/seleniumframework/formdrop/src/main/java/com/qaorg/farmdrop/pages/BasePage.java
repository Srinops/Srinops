package com.qaorg.farmdrop.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.qaorg.framework.base.DriverManager;

public abstract class BasePage {
	
	protected WebDriver driver;
	
	BasePage(){
		this.driver=DriverManager.getDriver();
		PageFactory.initElements(driver, this);
	}
	
	public abstract boolean isPageDisplayed();
}
