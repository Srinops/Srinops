package com.qaorg.farmdrop.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.qaorg.farmdrop.stepdefinitions.Hooks;
import com.qaorg.framework.utilities.DriverWait;
import com.qaorg.framework.utilities.Reporter;
import com.qaorg.framework.utilities.SoftAssertion;
import com.qaorg.framework.utilities.UIWrappers;

public class SignUpPage extends BasePage {

	Reporter report;
	public SignUpPage() {
		super();
		report=new Reporter(Hooks.getScenario());
	}

	@FindBy(id = "email") private WebElement emailTextField;
	@FindBy(id = "password") private WebElement pwdTextField;
	@FindBy(id = "zipcode")	private WebElement postCodeTextField;
	@FindBy(id = "//label[text()='Add me to the mailing list']") private WebElement mailingListRadioBtn;
	@FindBy(xpath = "//label[text()='No, thanks']")	private WebElement noThanksRadioBtn;
	@FindBy(id = "email-signup-form-submit") private WebElement submitBtn;
	@FindBy(xpath = "//div[contains(@class,'session__errors')]") private WebElement singUpFormErrorsContainer;

	public void fillEmailSignUpForm(String email, String password, String zipCode, String marketingOption) {
		UIWrappers.inputText(emailTextField, email);
		UIWrappers.inputText(pwdTextField, password);
		UIWrappers.inputText(postCodeTextField, zipCode);

		if ("No Thanks".equalsIgnoreCase(marketingOption)) {
			UIWrappers.clickElement(noThanksRadioBtn);
		} else if ("mailing list".equalsIgnoreCase(marketingOption)) {
			UIWrappers.clickElement(mailingListRadioBtn);
		}
		report.logger("User filled sign up form fields");
	}

	private WebElement singUpFormErrorMessages(String errorMessage) {
		return singUpFormErrorsContainer.findElement(By.xpath("//li[text()=\"" + errorMessage + "\"]"));
	}

	public void validateSignUpFormFieldLevelErrors(String email, String password, String zipCode) {
		if ("".equals(email)) {
			Assert.assertTrue(DriverWait.isElementDisplayed(singUpFormErrorMessages("Email can't be blank")),"Email can;t be blank error message is not displayed");
		}

		if ("".equals(password)) {
			Assert.assertTrue(DriverWait.isElementDisplayed(singUpFormErrorMessages("Password can't be blank")),"Password can't be blank error message is not displayed");
		}

		if ("".equals(zipCode)) {
			Assert.assertTrue(DriverWait.isElementDisplayed(singUpFormErrorMessages("Zipcode can't be blank")),"Zipcode can't be blank error message is not displayed");
		}
		report.logger("Error messages are displayed when data is not entered in mandatory fields");
	}

	public void verifySignUpFormFieldFormats() {
		System.out.print("title of" + emailTextField.getAttribute("title"));
	}

	public void validateSignUpFormFieldLabels() {
		SoftAssertion.assertTrue(emailTextField.getAttribute("placeholder").equals("Email address"),"Email addrress field label is not matched");
		SoftAssertion.assertTrue(pwdTextField.getAttribute("placeholder").equals("Password"),"Password field label is not matched");
		SoftAssertion.assertTrue(postCodeTextField.getAttribute("placeholder").equals("Postcode"),"Postcode field label is not matched");
		SoftAssertion.assertTrue(postCodeTextField.getText().equals("Postcode"), "Let's fix the food chain");
	}

	public void clickSubmitButton() {
		UIWrappers.clickElement(submitBtn);
	}

	public boolean isPageDisplayed() {
		return DriverWait.isElementDisplayed(submitBtn);
	}
}
