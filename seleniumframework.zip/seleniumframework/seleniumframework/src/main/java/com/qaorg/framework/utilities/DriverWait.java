package com.qaorg.framework.utilities;

import java.time.Duration;

import org.apache.log4j.Logger;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.google.common.base.Function;
import com.qaorg.framework.base.DriverManager;

public class DriverWait {

	private static WebDriver driver = DriverManager.getDriver();

	/**
	 * This method makes web driver to wait more than 2 mints for web element to
	 * display, if web element is not visible or not displayed after 2mints then
	 * method return false otherwise return true
	 * 
	 * @param element
	 *            - element to display in UAT
	 * @return boolean
	 */
	public static boolean isElementDisplayed(WebElement element) {
		Logger.getLogger(DriverWait.class).info(DriverWait.class.getEnclosingMethod().getName());
		Exception exception = null;
		for (int itrCount = 0; itrCount <= 60; itrCount++) {
			try {
				element.isDisplayed();
				return true;
			} catch (NoSuchElementException noSuch) {
				exception = noSuch;
			} catch (StaleElementReferenceException stale) {
				exception = stale;
			}
			customSleep(1);
		}
		Logger.getLogger(DriverWait.class).error(exception);
		return false;
	}

	/**
	 * Makes web driver to wait for element is enabled, if element is enabled in 2
	 * mints then return false
	 * 
	 * @param element
	 *            - element to display in UAT
	 * @return boolean
	 */
	public static boolean isElementEnabled(WebElement element) {
		Logger.getLogger(DriverWait.class).info(DriverWait.class.getEnclosingMethod().getName());
		if (isElementDisplayed(element)) {
			int itrCount = 0;
			do {
				if (element.isEnabled()) {
					return true;
				}
				customSleep(1);
				itrCount++;
			} while (itrCount <= 30);
		}
		return false;
	}

	/**
	 * Make thread to sleep for specified time
	 * 
	 * @param waitTime
	 *            - wait time in long
	 */
	public static void customSleep(long waitTime) {
		Logger.getLogger(DriverWait.class).info(DriverWait.class.getEnclosingMethod().getName());
		try {
			Thread.sleep(1000 * waitTime);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static class WebDriverWait {
		static org.openqa.selenium.support.ui.WebDriverWait wait;

		/**
		 * Initialize WebDriverWait
		 * 
		 * @param time
		 *            - wait time
		 */
		private static org.openqa.selenium.support.ui.WebDriverWait webDriverWait(long... time) {
			if (time.length > 0) {
				return new org.openqa.selenium.support.ui.WebDriverWait(driver, time[0]);
			} else {
				return new org.openqa.selenium.support.ui.WebDriverWait(driver, 30);
			}
		}

		/**
		 * Make web driver to wait till element state to be enabled to click on it
		 * 
		 * @param element
		 *            - web element
		 * @param time
		 *            - wait time
		 */
		public static void waitForElementToBeClickable(WebElement element, long... time) {
			Logger.getLogger(DriverWait.class).info(DriverWait.class.getEnclosingMethod().getName());
			wait = webDriverWait(time);
			wait.until(ExpectedConditions.elementToBeClickable(element));
		}

		/**
		 * Make web driver to wait current URL contains specified text
		 * 
		 * @param text
		 *            - text to search in URL
		 * @param time
		 *            - wait time
		 */
		public static void waitForTextInURL(String text, long... time) {
			Logger.getLogger(DriverWait.class).info(DriverWait.class.getEnclosingMethod().getName());
			wait = webDriverWait(time);
			wait.until(ExpectedConditions.urlContains(text));
		}

		/**
		 * Make web driver to wait till element to be visible on the page
		 * 
		 * @param element
		 *            - web element
		 * @param time
		 *            - wait time
		 */
		public static void waitForElementToBeVisible(WebElement element, long... time) {
			wait = webDriverWait(time);
			wait.until(ExpectedConditions.visibilityOf(element));
		}
	}

	public static class FluentWait {
		private static org.openqa.selenium.support.ui.FluentWait<WebDriver> wait;

		private static org.openqa.selenium.support.ui.FluentWait<WebDriver> waitIntervel(long... waitTime) {
			wait = new org.openqa.selenium.support.ui.FluentWait<WebDriver>(driver);
			if (waitTime.length > 0) {
				wait.withTimeout(Duration.ofSeconds(waitTime[0]));
			} else {
				wait.withTimeout(Duration.ofSeconds(60));
			}
			wait.pollingEvery(Duration.ofSeconds(2));
			wait.ignoring(Exception.class);
			return wait;
		}

		/**
		 * This method is used to wait for the element till specified time and to return
		 * status of element
		 * 
		 * @param element
		 *            - Provide locator of element.
		 * @param waitTime
		 *            - Provide timeout in seconds.
		 * @return
		 */
		public static boolean waitForElementToDisplay(WebElement element, long... waitTime) {
			Logger.getLogger(DriverWait.class).info(DriverWait.class.getEnclosingMethod().getName());
			wait = waitIntervel(waitTime);
			Function<WebDriver, Boolean> function = new Function<WebDriver, Boolean>() {
				@Override
				public Boolean apply(WebDriver input) {
					try {
						return element.isDisplayed();
					} catch (NoSuchElementException noSuch) {
						return false;
					} catch (ElementNotVisibleException notVisible) {
						return false;
					}
				}
			};
			return wait.until(function);
		}

		/**
		 * This method is used to wait for the element to be clicked till specified time
		 * and till clicked element is invisible
		 * 
		 * @param element
		 *            - Provide locator of element.
		 * @param waitTime
		 *            - Provide timeout in seconds.
		 * 
		 * @return
		 */
		public static void waitForElementToClick(WebElement element, long... waitTime) {
			Logger.getLogger(DriverWait.class).info(DriverWait.class.getEnclosingMethod().getName());
			wait = waitIntervel(waitTime);
			Function<WebDriver, Boolean> function = new Function<WebDriver, Boolean>() {
				@Override
				public Boolean apply(WebDriver input) {
					try {
						element.click();
						return true;
					} catch (NoSuchElementException soSuch) {
						return false;
					} catch (WebDriverException webDriverError) {
						return false;
					}
				}
			};
			wait.until(function);
		}
	}
}
