package com.qaorg.farmdrop.stepdefinitions;

import com.qaorg.framework.utilities.SoftAssertion;
import com.qaorg.framework.utilities.UIWrappers;

import io.cucumber.core.api.Scenario;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.AfterStep;

public class Hooks {

	private static Scenario sc;

	/**
	 * Called before every scenario
	 * 
	 * @param scenario
	 *            - scenario instance
	 */
	@Before
	public void beforeScenario(Scenario scenario) {
		sc = scenario;
		new SoftAssertion();
	}

	@BeforeStep
	public void beforeStep(Scenario scenario) {

	}

	/**
	 * Called after every step, take screenshot after step
	 * 
	 * @param scenario
	 *            - scenario instance
	 */
	@AfterStep
	public void AfterStep(Scenario scenario) {
		UIWrappers.takeScreenShot(scenario);
	}

	/**
	 * Called after every scenario, take screenshot on failure of scenario
	 * 
	 * @param scenario
	 *            - scenario instance
	 */
	@After
	public void afterScenario(Scenario scenario) {
		if (scenario.isFailed()) {
			UIWrappers.takeScreenShot(scenario);
		}
	}

	public static Scenario getScenario() {
		return sc;
	}
}
