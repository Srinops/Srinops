package com.qaorg.farmdrop.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.qaorg.farmdrop.stepdefinitions.Hooks;
import com.qaorg.framework.utilities.DriverWait;
import com.qaorg.framework.utilities.Reporter;
import com.qaorg.framework.utilities.UIWrappers;

public class LoginPage extends BasePage{
	
	private Reporter report;
	public LoginPage() {
		super();
		report=new Reporter(Hooks.getScenario());
	}

	@FindBy(xpath="//a[text()='Sign up']") private WebElement signUpLink;
	@FindBy(xpath="//a[contains(@class,'admin__accountLink')]") private WebElement accountToggleLink;
	
	
	public void clickSignUpLink() {
		UIWrappers.clickElement(signUpLink);
		Assert.assertTrue(new SignUpPage().isPageDisplayed(), "Either Sign up link is not working or Sign up page is not displayed");
		report.logger("Sign Up page is displayed successfully");
		
	}
	
	public void clickAccountToggleLink() {
		UIWrappers.clickElement(accountToggleLink);
	}
	
	public boolean isPageDisplayed() {
		return DriverWait.isElementDisplayed(signUpLink);
	}
}
